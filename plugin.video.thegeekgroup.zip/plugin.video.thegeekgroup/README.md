The Geek Group XBMC Addon
===============================
Watch shows from the [The Geek Group](http://www.Thegeekgroup.org) network in [XBMC](http://xbmc.org/).

Shows
-----
* [Live Show](http://www.thegeekgroup.org)


Instructions
------------
1. Download the addon from the official XBMC Addon Repository


About
-----
* Author: [MadManMarkAu] () [KB3NZQ]
* Source: [GitHub](https://github.com/KB3NZQ/XBMC-TheGeekGroup)
